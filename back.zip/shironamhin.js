const scroll = new LocomotiveScroll({
  el: document.querySelector("main"),
  smooth: true,
});

function allAnimation() {
  gsap.from(".nlink", {
    stagger: 0.1,
    ease: Power2,
    y: 10,
    duration: 0.9,
    opacity: 0,
  });

  Shery.textAnimate(".md-h1-div h1", {
    style: 2,
    y: 10,
    duration: 2,
    delay: 0.2,
    ease: "cubic-bezier(0.23, 1, 0.320, 1)",
  });

  gsap.from("#animation", {
    y: 50,
    duration: 1,
    delay: 0.1,
    ease: Expo,
  });

  Shery.imageEffect(".middle-part img", {
    style: 3,
    config: {
      uFrequencyX: { value: 12.21, range: [0, 100] },
      uFrequencyY: { value: 5.34, range: [0, 100] },
      uFrequencyZ: { value: 45.04, range: [0, 100] },
      geoVertex: { range: [1, 64], value: 18.31 },
      zindex: { value: -9996999, range: [-9999999, 9999999] },
      aspect: { value: 0.7500164983831584 },
      ignoreShapeAspect: { value: true },
      shapePosition: { value: { x: 0, y: 0 } },
      shapeScale: { value: { x: 0.5, y: 0.5 } },
      shapeEdgeSoftness: { value: 0, range: [0, 0.5] },
      shapeRadius: { value: 0, range: [0, 2] },
      currentScroll: { value: 0 },
      scrollLerp: { value: 0.07 },
      gooey: { value: false },
      infiniteGooey: { value: false },
      growSize: { value: 4, range: [1, 15] },
      durationOut: { value: 1, range: [0.1, 5] },
      durationIn: { value: 1.5, range: [0.1, 5] },
      displaceAmount: { value: 0.5 },
      masker: { value: true },
      maskVal: { value: 1.52, range: [1, 5] },
      scrollType: { value: 0 },
      noEffectGooey: { value: true },
      onMouse: { value: 1 },
      noise_speed: { value: 0.2, range: [0, 10] },
      metaball: { value: 0.2, range: [0, 2] },
      discard_threshold: { value: 0.5, range: [0, 1] },
      antialias_threshold: { value: 0.002, range: [0, 0.1] },
      noise_height: { value: 0.5, range: [0, 2] },
      noise_scale: { value: 10, range: [0, 100] },
    },
  });

  Shery.imageEffect("#level img", {
    style: 5,
    config: {
      a: { value: 1.6, range: [0, 30] },
      b: { value: -0.65, range: [-1, 1] },
      zindex: { value: -9996999, range: [-9999999, 9999999] },
      aspect: { value: 0.7153541575010999 },
      ignoreShapeAspect: { value: true },
      shapePosition: { value: { x: 0, y: 0 } },
      shapeScale: { value: { x: 0.5, y: 0.5 } },
      shapeEdgeSoftness: { value: 0, range: [0, 0.5] },
      shapeRadius: { value: 0, range: [0, 2] },
      currentScroll: { value: 0 },
      scrollLerp: { value: 0.07 },
      gooey: { value: false },
      infiniteGooey: { value: false },
      growSize: { value: 4, range: [1, 15] },
      durationOut: { value: 1, range: [0.1, 5] },
      durationIn: { value: 1.5, range: [0.1, 5] },
      displaceAmount: { value: 0.5 },
      masker: { value: true },
      maskVal: { value: 1.52, range: [1, 5] },
      scrollType: { value: 0 },
      geoVertex: { range: [1, 64], value: 18.31 },
      noEffectGooey: { value: true },
      onMouse: { value: 1 },
      noise_speed: { value: 0.2, range: [0, 10] },
      metaball: { value: 0.2, range: [0, 2] },
      discard_threshold: { value: 0.5, range: [0, 1] },
      antialias_threshold: { value: 0.002, range: [0, 0.1] },
      noise_height: { value: 0.5, range: [0, 2] },
      noise_scale: { value: 10, range: [0, 100] },
      uFrequencyX: { value: 12.21, range: [0, 100] },
      uFrequencyY: { value: 5.34, range: [0, 100] },
      uFrequencyZ: { value: 45.04, range: [0, 100] },
    },
  });

  gsap.from(".middle-part img", {
    y: 70,
    opacity: 0,
    duration: 2,
    ease: Expo,
  });
Shery.imageEffect(".bottel-img", {
style: 5,
gooey: true,
config:{"a":{"value":0.46,"range":[0,30]},"b":{"value":-0.98,"range":[-1,1]},"zindex":{"value":-9996999,"range":[-9999999,9999999]},"aspect":{"value":1.9328231292517006},"ignoreShapeAspect":{"value":true},"shapePosition":{"value":{"x":0,"y":0}},"shapeScale":{"value":{"x":0.5,"y":0.5}},"shapeEdgeSoftness":{"value":0,"range":[0,0.5]},"shapeRadius":{"value":0,"range":[0,2]},"currentScroll":{"value":0},"scrollLerp":{"value":0.07},"gooey":{"value":true},"infiniteGooey":{"value":true},"growSize":{"value":2.18,"range":[1,15]},"durationOut":{"value":0.66,"range":[0.1,5]},"durationIn":{"value":0.89,"range":[0.1,5]},"displaceAmount":{"value":0.5},"masker":{"value":true},"maskVal":{"value":1.21,"range":[1,5]},"scrollType":{"value":0},"geoVertex":{"range":[1,64],"value":1},"noEffectGooey":{"value":true},"onMouse":{"value":1},"noise_speed":{"value":0.2,"range":[0,10]},"metaball":{"value":0.2,"range":[0,2],"_gsap":{"id":3}},"discard_threshold":{"value":0.69,"range":[0,1]},"antialias_threshold":{"value":0,"range":[0,0.1]},"noise_height":{"value":0.21,"range":[0,2]},"noise_scale":{"value":17.56,"range":[0,100]}},
});
}
allAnimation();

function ballAnimation(){
  let gooey = document.querySelector('#our-video');

gooey.addEventListener('mouseenter',()=>{
  gsap.to('#ball',{
    opacity:1,
    scale:1,
  });
});

gooey.addEventListener('mouseleave',()=>{
  gsap.to('#ball',{
    opacity:0,
    scale:0,
  });
});

gooey.addEventListener('mousemove',(dets)=>{
  gsap.to('#ball',{
    x :dets.x - gooey.getBoundingClientRect().x - 40,
    y :dets.y - gooey.getBoundingClientRect().y - 40,
  });
});
}
ballAnimation();

function video(){
  let future = document.querySelector(".future-text");

future.addEventListener("mouseover", () => {
    gsap.to('video',{
        opacity:1,
        duration:1,
        ease: Power4,
    });
    gsap.to('#ball',{
      opacity:0,
    });
});
future.addEventListener("mouseleave", () => {
    gsap.to('video',{
        opacity:0,
        duration:1,
        ease: Power4,
    });
    gsap.to('#ball',{
      opacity:1,
    });
});
};
video();
